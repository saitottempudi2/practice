const mockData = [
  { country: "Aug-24", IOS: 1651, Andriod: 809 },
  { country: "Sep-24", IOS: 8721, Andriod: 2713 },
  { country: "Oct-24", IOS: 28248, Andriod: 7347 },
  { country: "Nov-24", IOS: 33273, Andriod: 7407 },
  { country: "Dec-24", IOS: 33146, Andriod: 7720 },
  { country: "Jan-25", IOS: 36205, Andriod: 8103 },
];

export default mockData;
