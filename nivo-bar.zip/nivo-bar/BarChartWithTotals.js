import React, { useState } from "react";
import { ResponsiveBar } from "@nivo/bar";
import { motion, AnimatePresence } from "framer-motion";

const BarChart = ({ data, colors }) => {
  const [tooltip, setTooltip] = useState(null);
  if (!data || data.length === 0) return <p>Loading...</p>;

  // Extract dynamic keys (first key is index)
  const indexBy = Object.keys(data[0])[0];
  const keys = Object.keys(data[0]).filter((key) => key !== indexBy);

  return (
    <div style={{ height: 500, position: "relative" }}>
      <ResponsiveBar
        data={data}
        keys={keys}
        indexBy={indexBy}
        margin={{ top: 50, right: 130, bottom: 50, left: 60 }}
        padding={0.3}
        valueScale={{ type: "linear" }}
        indexScale={{ type: "band", round: true }}
        colors={colors}
        enableLabel={true}
        enableTotals={true}
        totalsOffset={10}
        labelSkipWidth={12}
        labelSkipHeight={12}
        labelTextColor={{ from: "color", modifiers: [["darker", 1.6]] }}
        borderColor={{ from: "color", modifiers: [["darker", 1.6]] }}
   
        axisLeft={{
          tickSize: 5,
          tickPadding: 5,
          tickRotation: 0,
          legend: "Users",
          legendPosition: "middle",
          legendOffset: -40,
        }}
        legends={[
          {
            dataFrom: "keys",
            anchor: "bottom-right",
            direction: "column",
            translateX: 120,
            itemsSpacing: 2,
            itemWidth: 100,
            itemHeight: 20,
            symbolSize: 20,
            effects: [{ on: "hover", style: { itemOpacity: 1 } }],
          },
        ]}
        role="application"
        ariaLabel="Nivo bar chart"
        barAriaLabel={(e) => `${e.id}: ${e.formattedValue} in ${e.indexValue}`}
        onMouseEnter={(bar, event) => {
          setTooltip({
            x: event.clientX,
            y: event.clientY,
            data: bar,
          });
        }}
        onMouseLeave={() => setTooltip(null)}
      />
      <AnimatePresence>
        {tooltip && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            style={{
              position: "absolute",
              left: tooltip.x + 10,
              top: tooltip.y + 10,
              background: "#222",
              color: "#fff",
              padding: "6px 12px",
              borderRadius: "4px",
              fontSize: "14px",
              pointerEvents: "none",
            }}
          >
            <strong style={{ color: tooltip.data.color }}>{tooltip.data.id}</strong>: {tooltip.data.value}
            <br />
            <span style={{ opacity: 0.7 }}>in {tooltip.data.indexValue}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default BarChart;
