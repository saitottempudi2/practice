const chartColors = ["#ff6384", "#36a2eb", "#ffce56"];

export default chartColors;
