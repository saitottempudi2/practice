import { ResponsivePie } from "@nivo/pie";
import { motion } from "framer-motion"; // Import motion for animation

const AnimatedDonutChart = ({ data }) => {
    return (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <div style={{ height: 500, display: "flex", justifyContent: "center" }}>
                <ResponsivePie
                    data={data}
                    margin={{ top: 40, right: 100, bottom: 40, left: 40 }}
                    innerRadius={0.6}
                    padAngle={0.5}
                    cornerRadius={5}
                    activeOuterRadiusOffset={8}
                    
                    // Use assigned colors from data
                    colors={{ datum: "data.color" }}

                    // Border styles
                    borderWidth={1}
                    borderColor={{ from: "color", modifiers: [["darker", 0.2]] }}

                    // Arc Link Labels
                    arcLinkLabelsSkipAngle={10}
                    arcLinkLabelsThickness={3}
                    arcLinkLabelsColor={{ from: "color" }}
                    arcLinkLabelsTextColor={{ from: "color", modifiers: [["darker", 1.2]] }}

                    // Arc Labels
                    arcLabelsSkipAngle={10}
                    arcLabelsTextColor={{ from: "color", modifiers: [["darker", 2]] }}

                    // Animation
                    animate={true}
                    motionConfig="wobbly"

                    // Legends
                    legends={[
                        {
                            anchor: "right",
                            direction: "column",
                            translateX: 90,
                            itemWidth: 80,
                            itemHeight: 22,
                            itemTextColor: "#555",
                            symbolSize: 14,
                            symbolShape: "circle",
                            effects: [{ on: "hover", style: { itemTextColor: "#000" } }],
                        },
                    ]}
                />
            </div>
        </motion.div>
    );
};

export default AnimatedDonutChart;
