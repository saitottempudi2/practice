export const colorPalette = [
    "#fdbb30", "#76c7c0", "#f25f5c", "#247ba0", "#d62d20",
    "#ffb400", "#ff6361", "#bc5090", "#58508d", "#003f5c"
];

// Function to assign colors dynamically
export const getChartData = () => {
    const rawData = [
        { id: "javascript", label: "JavaScript", value: 45 },
        { id: "python", label: "Python", value: 35 },
        { id: "java", label: "Java", value: 25 },
        { id: "c", label: "C", value: 20 },
        { id: "ruby", label: "Ruby", value: 10 },
        { id: "php", label: "PHP", value: 15 }, // New data in the future
        { id: "swift", label: "Swift", value: 18 } // Another new entry
    ];

    // Assign colors dynamically
    return rawData.map((item, index) => ({
        ...item,
        color: colorPalette[index % colorPalette.length] // Cycle through colors if needed
    }));
};
