import React from "react";
import { motion } from "framer-motion";

const DonutLoader = () => {
    return (
        <motion.div
            initial={{ rotate: 0 }}
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 1.2, ease: "linear" }}
            style={{
                width: 80,
                height: 80,
                borderRadius: "50%",
                border: "6px solid #ddd",
                borderTop: "6px solid #76c7c0", // The animated section
                margin: "auto",
            }}
        />
    );
};

export default DonutLoader;
