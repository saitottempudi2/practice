import React, { useRef, useState, useEffect } from "react";
import "./ScrollableTabs.css";

const ScrollableTabs = ({ tabs, width = "400px" }) => {
  const scrollRef = useRef(null);
  const trackRef = useRef(null);
  const thumbRef = useRef(null);
  const [activeTab, setActiveTab] = useState(0);
  const [thumbWidth, setThumbWidth] = useState(50);
  const [thumbLeft, setThumbLeft] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const startX = useRef(0);
  const startScrollLeft = useRef(0);

  useEffect(() => {
    const updateThumb = () => {
      if (scrollRef.current && trackRef.current) {
        const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
        const trackWidth = trackRef.current.clientWidth;

        // Set thumb width proportional to visible area
        const newThumbWidth = Math.max((clientWidth / scrollWidth) * trackWidth, 40);
        setThumbWidth(newThumbWidth);

        // Set thumb position based on scroll position
        const newThumbLeft = (scrollLeft / (scrollWidth - clientWidth)) * (trackWidth - newThumbWidth);
        setThumbLeft(newThumbLeft);
      }
    };

    if (scrollRef.current) {
      scrollRef.current.addEventListener("scroll", updateThumb);
      updateThumb();
    }

    return () => {
      if (scrollRef.current) {
        scrollRef.current.removeEventListener("scroll", updateThumb);
      }
    };
  }, []);

  const handleTabClick = (index) => {
    setActiveTab(index);
    if (scrollRef.current) {
      const tabElement = scrollRef.current.children[index];
      if (tabElement) {
        scrollRef.current.scrollTo({ left: tabElement.offsetLeft - 20, behavior: "smooth" });
      }
    }
  };

  const handleThumbMouseDown = (event) => {
    event.stopPropagation(); // Prevent interference with track click
    setIsDragging(true);
    startX.current = event.clientX;
    startScrollLeft.current = scrollRef.current.scrollLeft;

    document.addEventListener("mousemove", handleThumbMouseMove);
    document.addEventListener("mouseup", handleThumbMouseUp);
  };

  const handleThumbMouseMove = (event) => {
    if (!isDragging || !scrollRef.current || !trackRef.current) return;

    const deltaX = event.clientX - startX.current;
    const trackWidth = trackRef.current.clientWidth - thumbWidth;
    const maxScrollLeft = scrollRef.current.scrollWidth - scrollRef.current.clientWidth;

    // Calculate new scroll position based on thumb movement
    const newScrollLeft = startScrollLeft.current + (deltaX / trackWidth) * maxScrollLeft;
    scrollRef.current.scrollLeft = Math.min(Math.max(newScrollLeft, 0), maxScrollLeft);
  };

  const handleThumbMouseUp = () => {
    setIsDragging(false);
    document.removeEventListener("mousemove", handleThumbMouseMove);
    document.removeEventListener("mouseup", handleThumbMouseUp);
  };

  const handleTrackClick = (event) => {
    if (!trackRef.current || !scrollRef.current) return;

    const trackRect = trackRef.current.getBoundingClientRect();
    const clickX = event.clientX - trackRect.left;

    // Calculate new scroll position
    const maxScrollLeft = scrollRef.current.scrollWidth - scrollRef.current.clientWidth;
    const newScrollLeft = (clickX / trackRef.current.clientWidth) * maxScrollLeft;

    scrollRef.current.scrollTo({ left: newScrollLeft, behavior: "smooth" });
  };

  const handleThumbClick = (event) => {
    event.stopPropagation(); // Prevent track click from firing
    handleTrackClick(event);
  };

  return (
    <div className="tabs-container" style={{ width }}>
      {/* Tabs Section */}
      <div className="tabs-wrapper" ref={scrollRef}>
        {tabs.map((tab, index) => (
          <div
            key={index}
            className={`tab-item ${activeTab === index ? "active" : ""}`}
            onClick={() => handleTabClick(index)}
          >
            {tab}
          </div>
        ))}
      </div>

      {/* Scrollbar Section */}
      <div className="scroll-track" ref={trackRef} onClick={handleTrackClick}>
        <div
          className="scroll-thumb"
          ref={thumbRef}
          style={{ width: `${thumbWidth}px`, left: `${thumbLeft}px` }}
          onMouseDown={handleThumbMouseDown}
          onClick={handleThumbClick} // Allow clicking on the thumb
        />
      </div>
    </div>
  );
};

export default ScrollableTabs;
