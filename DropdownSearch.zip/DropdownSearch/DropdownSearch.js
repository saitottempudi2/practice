import React, { useState, useMemo, useRef } from "react";
import { Dropdown, FormControl } from "react-bootstrap";
import { FixedSizeList as List } from "react-window";
import debounce from "lodash.debounce";
import "./DropdownSearch.css"; // Import CSS

const options = [
  "Apple", "Banana", "Cherry", "Date", "Grapes", "Orange", "Strawberry",
  "Mango", "Pineapple", "Blueberry", "Raspberry", "Blackberry", "Peach",
  "Pear", "Plum", "Apricot", "Coconut", "Fig", "Guava", "Kiwi", "Lemon",
  "Lime", "Lychee", "Mandarin", "Melon", "Nectarine", "Papaya", "Passion Fruit",
  "Pomegranate", "Raisin", "Tangerine", "Watermelon", "Cantaloupe", "Mulberry",
  "Cranberry", "Gooseberry", "Jackfruit", "Dragon Fruit", "Elderberry",
  "Avocado", "Cucumber", "Tomato", "Bell Pepper", "Carrot", "Broccoli",
  "Spinach", "Cabbage", "Cauliflower", "Pumpkin", "Radish"
];

export default function DropdownSearch() {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState("");
  const [filteredOptions, setFilteredOptions] = useState(options);
  const dropdownRef = useRef(null);

  const handleSearch = useMemo(
    () =>
      debounce((query) => {
        const filtered = options.filter(option =>
          option.toLowerCase().includes(query.toLowerCase())
        );
        setFilteredOptions(filtered);
      }, 300),
    []
  );

  const handleChange = (e) => {
    setSearch(e.target.value);
    handleSearch(e.target.value);
  };

  // Custom row renderer for virtualized list
  const Row = ({ index, style }) => (
    <div style={style}>
      <Dropdown.Item
        onClick={() => {
          setSelected(filteredOptions[index]);
          setSearch("");
          dropdownRef.current?.click(); // Close dropdown on selection
        }}
      >
        {filteredOptions[index]}
      </Dropdown.Item>
    </div>
  );

  return (
    <Dropdown className="w-100" ref={dropdownRef}>
      <Dropdown.Toggle variant="primary" className="w-100">
        {selected || "Select an option"}
      </Dropdown.Toggle>

      <Dropdown.Menu className="dropdown-menu-custom">
        <FormControl
          autoFocus
          placeholder="Search..."
          onChange={handleChange}
          value={search}
          className="mb-2"
        />

        {filteredOptions.length > 0 ? (
          <div className="scrollable-dropdown">
            <List height={200} itemCount={filteredOptions.length} itemSize={35} width="100%">
              {Row}
            </List>
          </div>
        ) : (
          <Dropdown.Item disabled>No results found</Dropdown.Item>
        )}
      </Dropdown.Menu>
    </Dropdown>
  );
}
