import React, { useState, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LabelList, Legend } from "recharts";
import { Container, Row, Col } from "react-bootstrap";
import { motion, AnimatePresence } from "framer-motion";
import themes from "./theme"; // Import themes
import "./BarChart.css";

const BarCharts = ({ timeframes, tabs, mode = "light" }) => {
    const [selectedIndex, setSelectedIndex] = useState(0);
    const [activeIndex, setActiveIndex] = useState(0);
    const visibleTabs = 2;
    const [theme, setTheme] = useState(themes.light);

    useEffect(() => {
        setTheme(mode === "dark" ? themes.dark : themes.light);
    }, [mode]);

    const nextTab = () => {
        if (selectedIndex < tabs.length - visibleTabs) {
            setSelectedIndex(selectedIndex + 1);
        }
    };

    const prevTab = () => {
        if (selectedIndex > 0) {
            setSelectedIndex(selectedIndex - 1);
        }
    };

    return (
        <Container className="chart-container" style={{ background: theme.background }}>
            <h3 className="text-center mt-3" style={{ color: theme.textPrimary }}>
                Active Users ({tabs[activeIndex]})
            </h3>

            {/* Legend Section */}
            <div className="text-center mb-4">
                <Legend
                    verticalAlign="bottom"
                    align="center"
                    wrapperStyle={{ background: theme.background, padding: "10px" }}
                    iconType="square"   // Change to square icons for better matching with bars
                    iconSize={10}
                />
            </div>

            {/* Tabs Section */}
            <Row className="tab-container align-items-center justify-content-center mt-3">
                <Col xs="auto">
                    <span
                        className={`arrow ${selectedIndex === 0 ? "disabled" : ""}`}
                        onClick={prevTab}
                        style={{ color: selectedIndex === 0 ? "#ccc" : theme.arrowColor }}
                    >
                        Prev
                    </span>
                </Col>

                <Col xs="auto">
                    <div className="tab-list" style={{ background: theme.tabBackground }}>
                        <AnimatePresence mode="wait">
                            {tabs.slice(selectedIndex, selectedIndex + visibleTabs).map((tab, index) => (
                                <motion.div
                                    key={tab}
                                    initial={{ opacity: 0, x: 30 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    exit={{ opacity: 0, x: -30 }}
                                    transition={{ duration: 0.3 }}
                                    className="tab-item"
                                    onClick={() => setActiveIndex(selectedIndex + index)}
                                    style={{
                                        color: activeIndex === selectedIndex + index ? theme.tabActiveText : theme.tabText,
                                        fontWeight: activeIndex === selectedIndex + index ? "bold" : "normal"
                                    }}
                                >
                                    {tab.charAt(0).toUpperCase() + tab.slice(1)}
                                </motion.div>
                            ))}
                        </AnimatePresence>
                    </div>
                </Col>

                <Col xs="auto">
                    <span
                        className={`arrow ${selectedIndex >= tabs.length - visibleTabs ? "disabled" : ""}`}
                        onClick={nextTab}
                        style={{ color: selectedIndex >= tabs.length - visibleTabs ? "#ccc" : theme.arrowColor }}
                    >
                        Next
                    </span>
                </Col>
            </Row>

            {/* Chart Section */}
            <div className="chart-content mt-4">
                <ResponsiveContainer width="100%" height={400}>
                    <BarChart data={timeframes[tabs[activeIndex]] || []} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                        <XAxis dataKey="name" tick={{ fill: theme.textPrimary }} />
                        <YAxis tick={{ fill: theme.textPrimary }} />

                      
                     
                        


                        {/* iOS Bar */}
                        <Bar dataKey="iOS" stackId="a" fill={theme.iosColor} radius={[10, 10, 0, 0]}>
                            <LabelList dataKey="iOS" position="middle" style={{ fill: "#fff", fontWeight: "bold" }} />
                        </Bar>

                        {/* Android Bar */}
                        <Bar dataKey="Android" stackId="a" fill={theme.androidColor} radius={[10, 10, 0, 0]}>
                            <LabelList dataKey="Android" position="middle" style={{ fill: "#fff", fontWeight: "bold" }} />
                        </Bar>

                        {/* Add Legend below the title */}
                        <Legend
                            verticalAlign="top"
                            iconType="square"   // Square icon for legend
                            iconSize={10}
                        />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </Container>
    );
};

export default BarCharts;
