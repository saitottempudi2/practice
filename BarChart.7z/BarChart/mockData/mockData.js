export const mockTimeframes = {
    weekly: [
      { name: "W1", iOS: 5000, Android: 2000 },
      { name: "W2", iOS: 7000, Android: 2500 },
      { name: "W3", iOS: 6500, Android: 2700 },
      { name: "W4", iOS: 8000, Android: 3000 }
    ],
    monthly: [
      { name: "Dec-24", iOS: 10471, Android: 3049 },
      { name: "Jan-13", iOS: 13872, Android: 3141 },
      { name: "Jan-20", iOS: 14022, Android: 3200 },
      { name: "Jan-27", iOS: 8391, Android: 2200 }
    ],
    yearly: [
      { name: "2022", iOS: 95000, Android: 54000 },
      { name: "2023", iOS: 120000, Android: 72000 },
      { name: "2024", iOS: 135000, Android: 89000 }
    ]
  };
  
  export const allTabs = ["weekly", "monthly", "yearly", "quarterly", "bi-annually", "decade","weekly", "monthly", "yearly", "quarterly", "bi-annually", "decade"];
  