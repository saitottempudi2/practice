const themes = {
    light: {
        background: "#ffffff",
        textPrimary: "#333",
        tabBackground: "#white",
        tabActive: "#aaa",
        iosColor: "#003f5c",
        androidColor: "#2f4b7c",
        grayBar: "#b0b0b0", // Light gray bar
        arrowColor: "#1890ff"
    },
    dark: {
        background: "#121212",
        textPrimary: "#f0f0f0",
        tabBackground: "white",
        tabActive: "#666",
        iosColor: "#003f5c",
        androidColor: "#2f4b7c",
        grayBar: "#666666", // Dark gray bar
        arrowColor: "#1890ff"
    }
};

export default themes;
